# 🗄️ Dokumentasi Resmi WidyaBase v1.0.0
### Mesin Basis Data Mandiri Berkinerja Native, Berdaulat & Skala Industri
 
> [!NOTE]
> 📘 **Buku Panduan PDF untuk Pemula**: Telah diterbitkan buku panduan resmi siap cetak/baca: [Buku_Panduan_WidyaBase_Pemula.pdf](file:///c:/widya-lang/Buku_Panduan_WidyaBase_Pemula.pdf).

---

## 🌟 1. Pendahuluan & Filosofi

**WidyaBase** adalah mesin basis data (*database engine*) mandiri berstandar industri yang dibangun secara orisinal di atas bahasa Widya-Lang dan inti mesin Rust. 

Berbeda dari sekadar *wrapper* atau adapter pustaka eksternal, WidyaBase dirancang dengan filosofi:
1. **Kedaulatan & Mandiri (*Autonomous & Self-Contained*)**: Memiliki struktur berkas biner slotted-page mandiri (`.wdb`) dan write-ahead log (`.wal`) tanpa ketergantungan runtime luar.
2. **SQL Dwibahasa Simetris (*Bilingual SQL Engine*)**: Mendukung penulisan kueri dalam **Bahasa Indonesia** (`PILIH ... DARI ... DIMANA`) dan **Standar ANSI Global** (`SELECT ... FROM ... WHERE`) dengan performa yang sama persis (0% overhead).
3. **Kompatibilitas Global via `pgwire` v3.0**: Menyediakan server daemon PostgreSQL Wire Protocol v3.0 sehingga dapat langsung diakses oleh alat standar industri seperti **DBeaver, pgAdmin, Prisma, Hibernate, psql, dan Grafana**.
4. **Multi-Modal Bawaan**: Mendukung data relasional terstruktur (ACID B+Tree), dokumen semi-terstruktur (JSONB), indeks kemiripan vektor AI (HNSW Cosine/Euclidean), dan penyimpanan kolumnar analitik.

---

## 🏛️ 2. Arsitektur 6 Pilar Industri

```
┌────────────────────────────────────────────────────────────────────────┐
│                        KLIEN / APLIKASI EKSTERNAL                      │
│        (Aplikasi Widya-Lang, psql, DBeaver, Prisma ORM, Grafana)       │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ TCP Port 5432 (pgwire v3.0)
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                           WIDYABASE CORE ENGINE                        │
│                                                                        │
│  [Pilar 1] SQL Parser Dwibahasa (Nusantara & Standar ANSI)             │
│  [Pilar 2] Multi-Version Concurrency Control (MVCC Snapshot Isolation) │
│  [Pilar 3] B+Tree Indexing O(log N) untuk Kunci Utama & Range Scan     │
│  [Pilar 4] Storage Slotted-Page 4096 Byte & In-Memory Buffer Pool      │
│  [Pilar 5] Write-Ahead Logging (WAL) & Crash Recovery Checkpoint       │
│  [Pilar 6] Multi-Modal AI (Vektor HNSW Cosine Similarity & JSONB)      │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                          MEDIA PENYIMPANAN DISK                        │
│         • database.wdb (Data Pages)  • database.wal (WAL Log)          │
└────────────────────────────────────────────────────────────────────────┘
```

### 1. Slotted-Page Storage 4KB & Buffer Pool
* Menggunakan halaman berukuran tetap 4096 byte (4 KB) berstandar industri dengan direktori slot tumbuh ke bawah dan penyimpanan data tumbuh ke atas dari akhir halaman.
* Buffer Pool Manager dengan paging memori dan kebijakan *LRU Eviction* adaptif.

### 2. Write-Ahead Logging (WAL) & Ketahanan ACID
* Setiap operasi (`BEGIN`, `INSERT`, `UPDATE`, `DELETE`, `COMMIT`) dicatat ke berkas biner `.wal` sebelum disiram ke disk.
* Algoritma pemulihan otomatis pasca-kegagalan (*Crash Recovery*) berbasis urutan LSN (Log Sequence Number).

### 3. Multi-Version Concurrency Control (MVCC)
* Mengimplementasikan *Snapshot Isolation*: Pembaca tidak pernah memblokir penulis (*readers never block writers*), dan penulis tidak pernah memblokir pembaca.
* Setiap baris dilindungi oleh penanda transaksi `xmin` (pembuat) dan `xmax` (penghapus).

### 4. B+Tree Indexing O(log N)
* Menyediakan pencarian cepat berlatensi sub-milidetik untuk kunci integer dan teks.
* Mendukung pemindaian rentang (*range scan*) yang efisien: `BETWEEN min AND max`.

### 5. Multi-Modal AI & JSONB
* **Vektor Kemiripan Kosinus & Jarak Euclidean**: Untuk pencarian embedding AI (RAG, pencarian semantik produk).
* **Parser Dokumen JSONB**: Ekstraksi dan pengindeksan field JSON tanpa overhead serialisasi.

### 6. Daemon PostgreSQL Wire Protocol v3.0 (`pgwire`)
* Mendukung negosiasi SSL, StartupMessage, AuthenticationOk, ParameterStatus, ReadyForQuery, RowDescription, dan DataRow.
* Berjalan di port default **5432** atau port kustom.

---

## 📖 3. Kamus Lengkap SQL Versi Bahasa Indonesia

WidyaBase memungkinkan pengembang menulis kueri SQL menggunakan kata-kata Bahasa Indonesia yang mengalir alami:

### A. Perintah Manipulasi Data (DML)
| Kata Kunci Indonesia | Standar Inggris | Contoh Sintaks |
| :--- | :--- | :--- |
| **`PILIH`** | `SELECT` | `PILIH nama, harga, stok` |
| **`DARI`** | `FROM` | `DARI menu_kopi` |
| **`DIMANA`** / **`DI_MANA`** | `WHERE` | `DIMANA harga >= 35000` |
| **`SISIP_KE`** / **`MASUKKAN_KE`** | `INSERT INTO` | `SISIP_KE kasir (id, total)` |
| **`NILAI`** | `VALUES` | `NILAI (1, 85000)` |
| **`PERBARUI`** / **`UBAH`** | `UPDATE` | `PERBARUI produk` |
| **`ATUR`** | `SET` | `ATUR stok = 20` |
| **`HAPUS_DARI`** | `DELETE FROM` | `HAPUS_DARI keranjang DIMANA id = 3` |

### B. Klausul Pengurutan, Batasan & Logika
| Kata Kunci Indonesia | Standar Inggris | Contoh Sintaks |
| :--- | :--- | :--- |
| **`GABUNG`** / **`GABUNG_DENGAN`** | `JOIN` / `INNER JOIN` | `GABUNG pelanggan PADA pesanan.pel_id = pelanggan.id` |
| **`PADA`** | `ON` | `PADA tabel_a.id = tabel_b.ref_id` |
| **`KELOMPOKKAN_BERDASARKAN`** | `GROUP BY` | `KELOMPOKKAN_BERDASARKAN kategori` |
| **`URUTKAN BERDASARKAN`** | `ORDER BY` | `URUTKAN BERDASARKAN harga TURUN` |
| **`NAIK`** / **`TURUN`** | `ASC` / `DESC` | `harga NAIK`, `tanggal TURUN` |
| **`SEPERTI`** / **`MIRIP`** | `LIKE` | `nama SEPERTI 'Kopi%'` atau `kode SEPERTI 'KOP-_1'` |
| **`ANTARA`** | `BETWEEN` | `harga ANTARA 10000 DAN 50000` |
| **`DI_DALAM`** | `IN` | `kategori DI_DALAM ('Makanan', 'Minuman')` |
| **`SEBAGAI`** / **`AS`** | `AS` | `harga * stok SEBAGAI total_nilai` |
| **`BATAS`** | `LIMIT` | `BATAS 10` |
| **`LEWATI`** | `OFFSET` | `LEWATI 20` |
| **`DAN`** / **`ATAU`** / **`BUKAN`** | `AND` / `OR` / `NOT` | `status = 'LUNAS' DAN total > 50000` |
| **`NIHIL`** | `NULL` | `catatan ADALAH NIHIL` |
| **`KUNCI_UTAMA`** | `PRIMARY KEY` | `id INT KUNCI_UTAMA` |
| **`KUNCI_ASING`** | `FOREIGN KEY` | `KUNCI_ASING (pel_id) REFERENSI pelanggan(id)` |
| **`REFERENSI`** | `REFERENCES` | `REFERENSI pelanggan(id)` |
| **`DENGAN`** | `WITH` | `DENGAN ringkasan SEBAGAI (PILIH ...)` |
| **`LEWAT`** | `OVER` | `NOMOR_BARIS() LEWAT (PARTISI_BERDASARKAN ...)` |
| **`PARTISI_BERDASARKAN`** | `PARTITION BY` | `PARTISI_BERDASARKAN divisi` |
| **`BUAT_INDEKS`** | `CREATE INDEX` | `BUAT_INDEKS idx_email PADA anggota(email)` |
| **`HAPUS_INDEKS`** | `DROP INDEX` | `HAPUS_INDEKS idx_email` |
| **`BUAT_TAMPILAN`** | `CREATE VIEW` | `BUAT_TAMPILAN v_aktif SEBAGAI PILIH ...` |
| **`HAPUS_TAMPILAN`** | `DROP VIEW` | `HAPUS_TAMPILAN v_aktif` |
| **`UBAH_TABEL`** | `ALTER TABLE` | `UBAH_TABEL anggota TAMBAH_KOLOM telp TEKS` |
| **`TAMBAH_KOLOM`** | `ADD COLUMN` | `TAMBAH_KOLOM alamat TEKS` |
| **`HAPUS_KOLOM`** | `DROP COLUMN` | `HAPUS_KOLOM alamat` |

### C. Fungsi Agregasi & Analitik
| Fungsi Indonesia | Standar Inggris | Keterangan |
| :--- | :--- | :--- |
| **`HITUNG(*)`** | `COUNT(*)` | Menghitung jumlah baris data |
| **`JUMLAH(kolom)`** | `SUM(column)` | Menjumlahkan nilai numerik total |
| **`RATA_RATA(kolom)`** | `AVG(column)` | Menghitung rata-rata nilai kolom |
| **`MIN(kolom)`** | `MIN(column)` | Mencari nilai terendah |
| **`MAKS(kolom)`** | `MAX(column)` | Mencari nilai tertinggi |
| **`NOMOR_BARIS()`** | `ROW_NUMBER()` | Menghasilkan nomor urut baris dalam partisi jendela analitik |
| **`PERINGKAT()`** | `RANK()` | Menghasilkan peringkat dengan celah (*gap*) saat nilai sama |
| **`DENSE_RANK()`** | `DENSE_RANK()` | Menghasilkan peringkat rapat (*dense rank*) tanpa celah |
| **`KEMIRIPAN_VEKTOR(k, v)`** | `COSINE_SIMILARITY(k, v)` | Menghitung kemiripan kosinus embedding AI |

### D. Kontrol Transaksi ACID & Transaksi Berjenjang
| Kata Kunci Indonesia | Standar Inggris | Keterangan |
| :--- | :--- | :--- |
| **`MULAI`** | `BEGIN` | Memulai sesi transaksi terisolasi |
| **`KOMIT`** / **`SIMPAN`** | `COMMIT` | Mengonfirmasi transaksi secara permanen |
| **`BATALKAN`** / **`GUGURKAN`** | `ROLLBACK` | Membatalkan seluruh perubahan transaksi |
| **`TITIK_SIMPAN <nama>`** | `SAVEPOINT <name>` | Menandai checkpoint di tengah transaksi aktif |
| **`GUGURKAN_KE <nama>`** | `ROLLBACK TO <name>` | Membatalkan perubahan kembali ke titik simpan spesifik |
| **`LEPAS_TITIK_SIMPAN <nama>`** | `RELEASE SAVEPOINT <name>` | Menghapus titik simpan tanpa membatalkan perubahan |

### E. Fitur Kueri Tingkat Lanjut (16 Pilar Mesin Basis Data Skala Enterprise)
WidyaBase mendukung manipulasi dan analitik data tingkat lanjut yang setara dengan basis data kelas enterprise:

#### 1. Filter Pasca-Agregasi (`MEMILIKI` / `HAVING`)
Memfilter grup data agregat setelah operasi `KELOMPOKKAN_BERDASARKAN` (`GROUP BY`).
```sql
PILIH kategori, RATA_RATA(harga) AS rata_harga, HITUNG(*) AS total
DARI produk
KELOMPOKKAN_BERDASARKAN kategori
MEMILIKI RATA_RATA(harga) > 500000
URUTKAN BERDASARKAN rata_harga TURUN;
```

#### 2. Deduplikasi Baris Proyeksi (`BERBEDA` / `DISTINCT` & `UNIK`)
Menghilangkan duplikat baris dari hasil kueri proyeksi maupun grup.
```sql
-- Mengambil daftar kota dan kategori unik tanpa duplikasi
PILIH BERBEDA kategori DARI inventaris;
PILIH UNIK kota, kategori DARI gudang URUTKAN BERDASARKAN kota NAIK;
SELECT DISTINCT category FROM products;
```

#### 3. Relasi Lintas-Tabel Lengkap (`INNER JOIN`, `GABUNG_KIRI` / `LEFT JOIN`, `GABUNG_KANAN` / `RIGHT JOIN`)
Mendukung Inner Join serta Outer Join (Left & Right Join) dengan baris tak berelasi diisi `NIHIL` (`NULL`).
```sql
-- Pelanggan yang belum memiliki pesanan tetap tampil dengan kolom pesanan bernilai NIHIL
PILIH p.nama, pes.id AS no_pesanan, JIKA_NIHIL(pes.total, 0) AS total_belanja
DARI pelanggan AS p
GABUNG_KIRI pesanan AS pes PADA p.id = pes.pelanggan_id
URUTKAN BERDASARKAN p.nama NAIK;
```

#### 4. Semantik & Pengecekan Nilai Kosong (`ADALAH NIHIL` / `IS NULL` & `BUKAN NIHIL` / `IS NOT NULL`)
Mengevaluasi nilai kosong (`NULL`) secara akurat sesuai standar SQL ANSI.
```sql
-- Temukan anggota yang belum melengkapi alamat email
PILIH nama, nomor_hp DARI anggota DIMANA email ADALAH NIHIL;

-- Temukan transaksi yang sudah diverifikasi (kolom verifikator bukan nihil)
SELECT id, total FROM transaksi WHERE verifikator IS NOT NULL;
```

#### 5. Ekspresi Kondisional & Fallback (`KASUS ... SELESAI` & `JIKA_NIHIL` / `COALESCE`)
Mendukung logika percabangan kondisional `CASE WHEN ... THEN ... ELSE ... END` serta fungsi substitusi nilai `COALESCE` / `IFNULL`.
```sql
PILIH nama, nilai,
      KASUS
          KETIKA nilai >= 85 MAKA 'A (Istimewa)'
          KETIKA nilai >= 70 MAKA 'B (Baik)'
          LAINNYA 'C (Cukup)'
      SELESAI AS predikat,
      JIKA_NIHIL(nomor_hp, 'Tidak Ada Kontak') AS kontak
DARI siswa
URUTKAN BERDASARKAN nilai TURUN;
```

#### 6. Pustaka Fungsi Skalar Bawaan (String, Matematika & Waktu)
Fungsi transformasi skalar lengkap yang dapat dipanggil pada kolom maupun tanpa tabel (`DUAL`):
* **Teks/String**: `HURUF_BESAR` (`UPPER`), `HURUF_KECIL` (`LOWER`), `PANJANG` (`LENGTH`), `GABUNG_TEKS` (`CONCAT`), `PANGKAS` (`TRIM`).
* **Matematika**: `BULATKAN` (`ROUND`), `ABSOLUT` (`ABS`), `LANTAI` (`FLOOR`), `ATAP` (`CEIL`).
* **Waktu/Temporal**: `SEKARANG()` (`NOW()`), `HARI_INI()` (`CURRENT_DATE`).
```sql
PILIH
    SEKARANG() AS waktu_server,
    HARI_INI() AS tanggal,
    HURUF_BESAR(nama) AS nama_kapital,
    BULATKAN(harga * 1.11, 2) AS harga_pajak,
    GABUNG_TEKS('SKU-', PANGKAS(kode_barang)) AS label_sku
DARI produk;
```

#### 7. Operasi Himpunan Set (`GABUNGAN` / `UNION` & `GABUNGAN_SEMUA` / `UNION ALL`)
Menggabungkan hasil dua kueri atau lebih, baik dengan deduplikasi otomatis (`UNION`) maupun menyimpan seluruh baris (`UNION ALL`).
```sql
-- Menggabungkan daftar produk dari dua gudang berbeda (tanpa duplikat)
PILIH nama_item, harga DARI gudang_jakarta
GABUNGAN
PILIH nama_item, harga DARI gudang_surabaya;

-- Menggabungkan seluruh log transaksi (termasuk duplikat)
SELECT id, waktu FROM log_cabang_1
UNION ALL
SELECT id, waktu FROM log_cabang_2;
```

#### 8. Subkueri & Evaluasi Sub-Seleksi (*Subqueries*)
Mendukung subkueri di dalam klausa `DIDALAM` / `IN` serta subkueri skalar pada operator perbandingan (`>`, `<`, `=`, dsb.) yang dieksekusi secara *deadlock-free* dan $O(1)$ per kueri:
```sql
-- Subkueri Himpunan (IN / DIDALAM)
PILIH nama, harga DARI produk
DIMANA id DIDALAM (PILIH produk_id DARI pesanan_item DIMANA kuantitas >= 5);

-- Subkueri Skalar (Mencari produk dengan harga di atas rata-rata keseluruhan)
SELECT nama, harga FROM produk
WHERE harga > (SELECT AVG(harga) FROM produk);
```

#### 9. Kueri Vektor AI Terintegrasi SQL (Semantic Search Langsung)
```sql
PILIH id, judul, KEMIRIPAN_VEKTOR(embedding, '[0.9, 0.1, 0.0]') AS skor 
DARI artikel 
DIMANA KEMIRIPAN_VEKTOR(embedding, '[0.9, 0.1, 0.0]') > 0.8 
URUTKAN BERDASARKAN skor TURUN;
```

#### 10. Common Table Expressions / CTE (`DENGAN ... SEBAGAI` / `WITH ... AS`)
Menyediakan tabel sementara (*ephemeral in-memory views*) untuk menyusun kueri analitik multi-tahap, laporan keuangan ERP, dan agregasi bertingkat dengan kejelasan tinggi:
```sql
-- Versi Bahasa Indonesia
DENGAN ringkasan_divisi SEBAGAI (
    PILIH divisi, JUMLAH(gaji) AS total_gaji
    DARI karyawan
    KELOMPOKKAN_BERDASARKAN divisi
)
PILIH divisi, total_gaji DARI ringkasan_divisi
DIMANA total_gaji > 100000000
URUTKAN BERDASARKAN total_gaji TURUN;

-- Versi Standar ANSI SQL
WITH regional_sales AS (
    SELECT region, SUM(amount) AS total_sales
    FROM orders
    GROUP BY region
)
SELECT region, total_sales FROM regional_sales
WHERE total_sales > 50000;
```

#### 11. Fungsi Jendela Analitik (*Window Functions*)
Memungkinkan perhitungan analitik tingkat lanjut baris demi baris tanpa menggabungkan (*collapse*) baris asli seperti pada `GROUP BY`.
* **Fungsi Peringkat & Urutan**: `NOMOR_BARIS()` (`ROW_NUMBER()`), `PERINGKAT()` (`RANK()`), `DENSE_RANK()`.
* **Fungsi Agregasi Terjendela**: `JUMLAH(...) LEWAT (...)` (`SUM(...) OVER (...)`), `RATA_RATA(...) LEWAT (...)` (`AVG(...) OVER (...)`), `HITUNG(...) LEWAT (...)` (`COUNT(...) OVER (...)`).
* **Spesifikasi Partisi & Urutan**: `LEWAT (PARTISI_BERDASARKAN <kolom> URUTKAN_BERDASARKAN <kolom>)` / `OVER (PARTITION BY <col> ORDER BY <col>)`.
```sql
-- Analitik Gaji Karyawan per Divisi dengan Pemeringkatan & Total Berjalan
PILIH nama, divisi, gaji,
      NOMOR_BARIS() LEWAT (PARTISI_BERDASARKAN divisi URUTKAN_BERDASARKAN gaji TURUN) AS no_baris,
      PERINGKAT() LEWAT (PARTISI_BERDASARKAN divisi URUTKAN_BERDASARKAN gaji TURUN) AS ranking,
      JUMLAH(gaji) LEWAT (PARTISI_BERDASARKAN divisi) AS total_divisi
DARI karyawan
URUTKAN BERDASARKAN divisi NAIK, gaji TURUN;

-- Standar ANSI SQL
SELECT name, department, salary,
       ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) as row_num,
       DENSE_RANK() OVER (PARTITION BY department ORDER BY salary DESC) as dense_rank,
       AVG(salary) OVER (PARTITION BY department) as avg_dept_salary
FROM employees;
```

#### 12. Indeks B+Tree Sekunder Eksplisit (`BUAT_INDEKS` / `CREATE INDEX`)
Meningkatkan performa pencarian kolom non-kunci utama (seperti email, nomor HP, status) dari pemindaian sekuensial $O(N)$ menjadi pencarian pohon $O(\log N)$ instan:
```sql
-- Membuat indeks sekunder pada kolom email
BUAT_INDEKS idx_anggota_email PADA anggota (email);
CREATE INDEX idx_orders_status ON orders (status);

-- Kueri pencarian akan otomatis memanfaatkan pemindaian indeks (Index Scan)
PILIH * DARI anggota DIMANA email = 'budi@widya.id';

-- Menghapus indeks jika sudah tidak diperlukan
HAPUS_INDEKS idx_anggota_email;
DROP INDEX idx_orders_status;
```

#### 13. Tampilan Virtual (*Virtual Views*) (`BUAT_TAMPILAN` / `CREATE VIEW`)
Menyediakan abstraksi kueri cerdas tanpa menduplikasi data fisik di disk. Kueri yang memanggil view diekspansi secara dinamis:
```sql
-- Membuat view untuk produk dengan stok menipis
BUAT_TAMPILAN v_stok_kritis SEBAGAI
PILIH id, nama, stok, harga
DARI produk
DIMANA stok <= 5;

-- Mengakses view seperti tabel biasa
PILIH * DARI v_stok_kritis URUTKAN BERDASARKAN stok NAIK;

-- Menghapus view
HAPUS_TAMPILAN v_stok_kritis;
DROP VIEW IF EXISTS v_critical_stock;
```

#### 14. Evolusi Skema Dinamis (*Schema Evolution*) (`UBAH_TABEL` / `ALTER TABLE`)
Mengubah struktur tabel secara dinamis tanpa downtime dan tanpa kehilangan data yang sudah tersimpan:
```sql
-- Menambahkan kolom baru (baris lama otomatis terisi NIHIL / NULL)
UBAH_TABEL anggota TAMBAH_KOLOM nomor_hp TEKS;
ALTER TABLE employees ADD COLUMN join_date TEKS;

-- Menghapus kolom dari skema dan baris data
UBAH_TABEL anggota HAPUS_KOLOM catatan;
ALTER TABLE employees DROP COLUMN obsolete_notes;
```

#### 15. Integritas Referensial Kunci Asing (*Foreign Key Referential Integrity*)
Menjamin validitas hubungan data antar-tabel secara ketat. Operasi `SISIP_KE` (`INSERT`) dan `PERBARUI` (`UPDATE`) yang merujuk pada nilai yang tidak terdaftar di tabel induk akan ditolak secara atomik:
```sql
-- Tabel Induk (Parent Table)
BUAT_TABEL departemen (
    id INT KUNCI_UTAMA,
    nama_dept TEKS
);

-- Tabel Anak dengan Batasan Kunci Asing (Child Table)
BUAT_TABEL pegawai (
    id INT KUNCI_UTAMA,
    nama TEKS,
    dept_id INT,
    KUNCI_ASING (dept_id) REFERENSI departemen (id)
);

-- Upaya memasukkan dept_id yang belum terdaftar akan menghasilkan:
-- "Pelanggaran Kunci Asing (Foreign Key Violation): Nilai '99' pada kolom 'dept_id' tidak ditemukan di tabel rujukan 'departemen(id)'"
```

#### 16. Transaksi Berjenjang & Titik Simpan (*Savepoints & Nested Rollback*)
Menyediakan kontrol transaksi berbutir halus (*fine-grained*) di dalam blok transaksi aktif, memungkinkan pembatalan parsial tanpa menggagalkan seluruh alur kerja:
```sql
MULAI;

-- Langkah 1: Pengisian saldo awal
PERBARUI dompet ATUR saldo = 1500000 DIMANA id = 1;

-- Menandai titik simpan aman
TITIK_SIMPAN sebelum_transfer;

-- Langkah 2: Operasi yang mengalami kegagalan/kesalahan input
PERBARUI dompet ATUR saldo = 200000 DIMANA id = 1;

-- Membatalkan HANYA langkah 2 kembali ke titik simpan
GUGURKAN_KE sebelum_transfer;

-- Melepas checkpoint dan mengonfirmasi transaksi akhir secara permanen
LEPAS_TITIK_SIMPAN sebelum_transfer;
KOMIT;
```

---

## 🖥️ 4. Antarmuka Baris Perintah: `WidyaBase.exe` & `widya base`

WidyaBase dapat dijalankan dengan dua cara:
1. **Biner Mandiri (*Standalone Executable*)**: `WidyaBase.exe` (atau `widyabase` di Linux/macOS) — sangat cocok untuk lingkungan server database dedicated, container Docker, atau pipeline CI/CD tanpa perlu seluruh runtime compiler Widya-Lang.
2. **Subkomando CLI Ekosistem**: `widya base ...` — terintegrasi langsung di dalam CLI utama `widya`.

### A. Menjalankan Biner Mandiri `WidyaBase.exe`

```bash
# 1. Buka shell interaktif SQL secara instan (default)
WidyaBase.exe

# 2. Menjalankan Server Daemon PostgreSQL Wire Protocol (Port 5432)
WidyaBase.exe mulai --port 5432 --data /var/lib/widyabase/pos.wdb

# 3. Inisialisasi basis data baru beserta WAL
WidyaBase.exe inisialisasi --data /var/lib/widyabase/pos.wdb

# 4. Mengeksekusi satu baris kueri dengan output tabel / JSON / CSV
WidyaBase.exe kueri "PILIH * DARI produk DIMANA harga >= 25000;" --data pos.wdb --format json

# 5. Memeriksa kesehatan, buffer pool, dan integritas berkas
WidyaBase.exe periksa --data pos.wdb

# 6. Melakukan flush buffer pool dan checkpoint WAL
WidyaBase.exe sinkronisasi --data pos.wdb

# 7. Utilitas Multi-Modal AI: kalkulasi kemiripan embedding vektor
WidyaBase.exe vektor "[0.9, 0.1, 0.0]" "[0.85, 0.15, 0.05]"
```

### B. Menjalankan via Subkomando `widya base`

### 1. Inisialisasi Database Baru
```bash
widya base inisialisasi /var/lib/widyabase/pos.wdb
```

### 2. Jalankan Server Daemon (pgwire Port 5432)
```bash
widya base mulai --port 5432 --data /var/lib/widyabase/pos.wdb
```

### 3. Jalankan Terminal Interaktif SQL (REPL Dwibahasa)
```bash
widya base sql --data /var/lib/widyabase/pos.wdb
```
*Tampilan Terminal:*
```text
============================================================
  🗄️  WIDYABASE INTERACTIVE REPL v1.0.0 (SQL DWIBAHASA)
  Mendukung: PILIH, SISIP_KE, PERBARUI, HAPUS_DARI, BUAT_TABEL
             SELECT, INSERT INTO, UPDATE, DELETE FROM, CREATE TABLE
  Ketik '\q' atau 'keluar' untuk keluar dari terminal.
============================================================
widyabase> PILIH * DARI produk DIMANA harga >= 30000;
┌────────────────────────────────────────────────────────┐
│ id    | nama        | harga    | stok                  │
├────────────────────────────────────────────────────────┤
│ 1     | Kopi Gayo   | 35000    | 15                    │
│ 2     | Kopi Toraja | 42000    | 8                     │
└────────────────────────────────────────────────────────┘
(2 baris)
```

### 4. Eksekusi Satu Baris Kueri Langsung
```bash
widya base kueri "PILIH HITUNG(*), JUMLAH(total) DARI transaksi;" --data pos.wdb
```

### 5. Audit & Pemeriksaan Kesehatan Halaman
```bash
widya base periksa /var/lib/widyabase/pos.wdb
```
*Hasil Audit:*
```text
============================================================
  🗄️  LAPORAN KESEHATAN BASIS DATA WIDYABASE v1.0.0
============================================================
📂 Berkas Target      : pos.wdb
📄 Total Halaman 4KB  : 24
📊 Jumlah Tabel Aktif : 4
📝 Rekod Log WAL      : 1250
🧠 Buffer Pool Cache  : Aktif (512 Halaman Terkelola)
🛡️  Status Integritas : SEHAT & KONSISTEN (ACID OK)
============================================================
```

---

## 🚀 5. Penggunaan di Bahasa Widya-Lang (`modul/widyabase.wya`)

Pengembang dapat menggunakan modul resmi `modul/widyabase.wya`:

```widya
impor "modul/widyabase.wya";

misal db = BukaWidyaBase("data/kasir_studio.wdb");

// 1. Buat Tabel
db.eksekusi("BUAT_TABEL menu (id INT KUNCI_UTAMA, nama TEKS, harga ANGKA);");

// 2. Sisip Data
db.eksekusi("SISIP_KE menu (id, nama, harga) NILAI (1, 'Kopi Gula Aren', 22000);");
db.eksekusi("SISIP_KE menu (id, nama, harga) NILAI (2, 'Croissant Coklat', 28000);");

// 3. Kueri Data
misal hasil = db.kueri("PILIH nama, harga DARI menu DIMANA harga > 20000;");
untuk baris dalam hasil {
    cetak("Menu: " + baris["nama"] + " - Rp " + ke_teks(baris["harga"]));
}

// 4. Checkpoint WAL
db.simpan();
```

---

## 🌐 6. Konektivitas Klien Standar Global (DBeaver, psql & Prisma)

Karena WidyaBase mengimplementasikan **PostgreSQL Wire Protocol v3.0**, aplikasi eksternal apa pun dapat tersambung:

### A. Menghubungkan lewat `psql` (CLI PostgreSQL)
```bash
psql -h 127.0.0.1 -p 5432 -U admin -d pos_db
```
Anda dapat mengetikkan kueri `SELECT * FROM produk;` maupun `PILIH * DARI produk;` secara langsung di prompt `psql`!

### B. Menghubungkan lewat GUI DBeaver / pgAdmin
1. Buka DBeaver > **New Database Connection** > Pilih **PostgreSQL**.
2. Masukkan Host: `127.0.0.1`, Port: `5432`, Database: `pos_db`, User: `admin`.
3. Klik **Test Connection** > Tersambung secara instan!

---

## 🧠 7. Multi-Modal AI (Vektor HNSW Cosine Similarity)

WidyaBase menyediakan kalkulasi kemiripan embedding langsung untuk aplikasi berbasis AI dan Large Language Models:

```rust
use widya::widyabase::multimodal::{VectorEngine, VectorRecord};

let v1 = vec![0.9, 0.1, 0.0];
let v2 = vec![0.85, 0.15, 0.05];

let skor_kemiripan = VectorEngine::cosine_similarity(&v1, &v2);
// Hasil: 0.998 (Sangat mirip)
```

---

## 🛡️ 8. Status Kepatuhan & Ringkasan

* **ACID Compliance**: Terpenuhi 100% via kombinasi WAL group commit dan MVCC Snapshot Isolation.
* **Storage Footprint**: Ukuran halaman 4096-byte terstandar dengan slot directory dan free-space tracking.
* **Dialek Dwibahasa**: Simetris 100% tanpa penurunan performa.
* **Ekosistem**: Terintegrasi penuh dengan CLI `widya base`, runtime interpreter, dan modul `modul/widyabase.wya`.
